// PLAY TALK v14.19 service worker — background push + safe navigation

// Keep this handler before Firebase imports so the app can handle clicks even if SDK setup fails.
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const wrapped = event.notification.data || {};
  const fcm = wrapped.FCM_MSG || wrapped;
  const payloadData = fcm.data || wrapped.data || {};
  const roomId = payloadData.roomId || payloadData.room || null;
  event.waitUntil(clients.matchAll({type:'window', includeUncontrolled:true}).then(async windows => {
    const base = new URL('./index.html', self.location.href);
    if (roomId) base.searchParams.set('openRoom', roomId);
    const current = windows.find(w => new URL(w.url).origin === self.location.origin && new URL(w.url).pathname.startsWith(new URL('./', self.location.href).pathname));
    if (current) {
      await current.focus();
      if (roomId) current.postMessage({openRoom: roomId});
    } else {
      await clients.openWindow(base.toString());
    }
  }));
});

importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js');
const ptFirebaseConfig = {
  apiKey: 'AIzaSyBAxe68hO8rqxRzJMfp4QPkT1RQRTCxm8',
  authDomain: 'play-talk-e7fc2.firebaseapp.com',
  databaseURL: 'https://play-talk-e7fc2-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'play-talk-e7fc2',
  storageBucket: 'play-talk-e7fc2.firebasestorage.app',
  messagingSenderId: '974837347426',
  appId: '1:974837347426:web:675f73cb66fc7facca8d3b',
  measurementId: 'G-PJR6VF7QJZ'
};
try {
  if (!firebase.apps.length) firebase.initializeApp(ptFirebaseConfig);
  const messaging = firebase.messaging();
  // Cloud Function sends DATA ONLY. This avoids duplicate browser notifications.
  messaging.onBackgroundMessage(payload => {
    const data = payload?.data || {};
    if (data.type !== 'chat_message') return;
    const roomId = String(data.roomId || '');
    const title = String(data.title || 'PLAY TALK');
    const body = String(data.body || '새 메시지가 도착했어요.');
    return self.registration.showNotification(title, {
      body,
      icon: './icons/icon-192.png',
      badge: './icons/icon-192.png',
      tag: roomId ? `play-talk-${roomId}` : 'play-talk-message',
      renotify: true,
      requireInteraction: false,
      vibrate: [350, 120, 450, 120, 600],
      data: { roomId, messageId: String(data.messageId || '') }
    });
  });
} catch (error) {
  console.error('PLAY TALK FCM service worker setup failed', error);
}

const CACHE = 'play-talk-v14.19';
const CORE = ['./', './index.html', './manifest.webmanifest', './manifest.json', './icons/icon-192.png', './icons/icon-512.png'];
self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  try { await cache.addAll(CORE); } catch (error) { console.warn('Some app shell files were not cached', error); }
  await self.skipWaiting();
})()));
self.addEventListener('activate', event => event.waitUntil((async () => {
  const keys = await caches.keys();
  await Promise.all(keys.filter(key => key.startsWith('play-talk-') && key !== CACHE).map(key => caches.delete(key)));
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const request = event.request, url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try { const response = await fetch(request, {cache:'no-store'}); if(response.ok){const cache=await caches.open(CACHE);await cache.put('./index.html',response.clone())} return response; }
      catch (_) { return (await caches.match('./index.html')) || Response.error(); }
    })()); return;
  }
  if (url.pathname.endsWith('/sw.js') || url.pathname.endsWith('/index.html') || url.pathname.endsWith('/manifest.webmanifest')) {
    event.respondWith(fetch(request,{cache:'no-store'}).catch(()=>caches.match(request).then(found=>found||Response.error()))); return;
  }
  event.respondWith(caches.match(request).then(found=>found||fetch(request).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(request,copy))}return response})))
});
