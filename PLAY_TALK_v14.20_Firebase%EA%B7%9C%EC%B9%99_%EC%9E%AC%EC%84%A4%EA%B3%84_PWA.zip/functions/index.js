const { onValueCreated } = require('firebase-functions/v2/database');
const { initializeApp } = require('firebase-admin/app');
const { getDatabase } = require('firebase-admin/database');
const { getMessaging } = require('firebase-admin/messaging');
const logger = require('firebase-functions/logger');

initializeApp({ databaseURL: 'https://play-talk-e7fc2-default-rtdb.asia-southeast1.firebasedatabase.app' });
const db = getDatabase();
const messaging = getMessaging();

/**
 * Sends a generic, data-only notification for a new encrypted 1:1 message.
 * The message body, keys and ciphertext are never included in the push payload.
 */
exports.sendChatPush = onValueCreated({
  ref: 'messages/{roomId}/{messageId}',
  instance: 'play-talk-e7fc2-default-rtdb',
  region: 'asia-southeast1',
  retry: false
}, async (event) => {
  const message = event.data?.val();
  const { roomId, messageId } = event.params;
  if (!message || message.type !== 'e2ee' || message.encrypted !== true || !message.sender) return;

  const roomSnap = await db.ref(`rooms/${roomId}`).get();
  const room = roomSnap.val();
  if (!room || room.group !== false || !room.members || room.members[message.sender] !== true) return;

  const recipients = Object.keys(room.members).filter(uid => room.members[uid] === true && uid !== message.sender);
  if (!recipients.length) return; // Do not notify a self-chat.
  let sentCount = 0, failedCount = 0;

  for (const uid of recipients) {
    const sender = message.sender;
    const [forward, reverse, blockedA, blockedB, tokenSnap] = await Promise.all([
      db.ref(`friendships/${sender}/${uid}`).get(),
      db.ref(`friendships/${uid}/${sender}`).get(),
      db.ref(`blocks/${sender}/${uid}`).get(),
      db.ref(`blocks/${uid}/${sender}`).get(),
      db.ref(`pushTokens/${uid}`).get()
    ]);
    if (forward.val() !== true || reverse.val() !== true || blockedA.exists() || blockedB.exists()) continue;

    const entries = Object.entries(tokenSnap.val() || {}).filter(([, row]) => typeof row?.token === 'string' && row.token.length >= 40);
    for (let start = 0; start < entries.length; start += 500) {
      const batch = entries.slice(start, start + 500);
      if (!batch.length) continue;
      const response = await messaging.sendEachForMulticast({
        tokens: batch.map(([, row]) => row.token),
        // Data-only is intentional: sw.js displays the notification with onBackgroundMessage.
        data: {
          type: 'chat_message',
          title: 'PLAY TALK',
          body: '새 메시지가 도착했어요.',
          roomId: String(roomId),
          messageId: String(messageId)
        },
        webpush: { headers: { Urgency: 'high', TTL: '86400' } }
      });
      sentCount += response.successCount;
      failedCount += response.failureCount;
      const removals = [];
      response.responses.forEach((result, index) => {
        if (!result.success) {
          const code = result.error?.code || '';
          if (code.includes('registration-token-not-registered') || code.includes('invalid-registration-token')) {
            removals.push(db.ref(`pushTokens/${uid}/${batch[index][0]}`).remove());
          }
        }
      });
      if (removals.length) await Promise.allSettled(removals);
    }
  }
  logger.info('PLAY TALK data-only push processed', { roomId, messageId, sentCount, failedCount });
});
